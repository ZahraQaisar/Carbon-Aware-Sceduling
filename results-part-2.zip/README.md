# Carbon-Aware Scheduling: 24-Hour Forecasting of Half-Hourly Grid Carbon Intensity

Course project: Data Science Tools and Techniques (MSDS).
Team: Zahra Qaisar (26L-8024) and Kainat Bashir (26L-8026).

## What this project does
The model predicts the carbon intensity of the Great Britain electricity grid for the next 24 hours
(48 half-hourly values) and recommends the cleanest 3-hour window of the day.
It uses data up to 23:30 UTC of the previous day (past carbon intensity, fuel mix, weather and calendar)
plus the weather of the target day.

- Part 1: data collection, cleaning, features and baselines (notebooks/part-1.ipynb)
- Part 2: models, tuning, optimization, evaluation, RQ1-RQ4, final model and predict(date) (notebooks/part-2.ipynb)

## Method in short
- Time-based split: train 2022-2023, validate 2024, then refit on 2022-2024 and test once on 2025.
- Baselines: same time yesterday, average of the last 7 days (NESO's own forecast is shown only as a reference).
- Models: Ridge, Random Forest, LightGBM (one pooled model and a per-slot test), and an ensemble.
- Tuning on the validation year, time-series cross-validation, ablation of feature groups, learning curves.
- Final model: ensemble of 80% Ridge and 20% LightGBM, chosen on validation data only.

## Main results (test year 2025, 361 days)
| Model | MAE (gCO2/kWh) |
|---|---|
| Final ensemble (80% Ridge + 20% LightGBM) | 19.81 |
| Ridge | 20.55 |
| LightGBM | 19.65 |
| Random Forest | 22.65 |
| Yesterday baseline | 38.87 |
| 7-day average baseline | 42.08 |
| NESO forecast (reference only, different horizon) | 9.19 |

- RQ1: the final model is about 49% better than the best simple baseline (the target was 20%).
- RQ2: MAE grows from 3.65 (00:00) to 29.69 (23:30).
- RQ3: forecast weather instead of historical weather did not make the model worse (MAE 19.27 vs 19.81).
- RQ4: the recommended window has a regret of 5.82 (Yesterday baseline 21.72); hit rate is 58.7%.
- The 80% prediction range covers 81.0% of the real 2025 values.

## Limitations
- The model predicts too high on average (bias about +8 gCO2/kWh); carbon intensity fell over the years.
- Windy days and winter are harder; the prediction ranges do not adapt to difficult days.
- The historical weather also comes from a weather-model API, so RQ3 may underestimate the loss from real forecasts.
- All times are in UTC. We predict average carbon intensity, not the carbon intensity of the next unit of electricity.

## Repository structure
    README.md
    requirements.txt
    notebooks/   part-1.ipynb, part-2.ipynb
    data/        master_clean.csv, selected_features.csv, previous_day1_2025.csv
    models/      final_model.joblib
    results/     results_*.csv, interval_offsets.csv
    figures/     all pictures of Part 2

## How to reproduce
1. Install the packages:  pip install -r requirements.txt
2. Part 1 creates master_clean.csv and selected_features.csv (copies are in the data folder).
3. Open notebooks/part-2.ipynb and run all cells from top to bottom. If the Kaggle folder is not found,
   the notebook reads the files from the data folder. The notebook writes its outputs to /kaggle/working
   (it exists on Kaggle; on your own computer create this folder first).
4. The 2025 one-day-ahead weather forecast is read from data/previous_day1_2025.csv, or downloaded from Open-Meteo.
5. The last part of the notebook downloads the latest data and forecasts today (internet needed).
   If the download fails, this part is skipped and the rest of the notebook is not affected.
6. Forecast for one date: run predict("2025-08-01") in the notebook.

## Data sources
- Carbon Intensity API (NESO), licence CC BY 4.0: https://api.carbonintensity.org.uk
- Open-Meteo (Historical Forecast, Previous Runs and Forecast APIs), licence CC BY 4.0: https://open-meteo.com

## Notes
- Random seed: 42.
- The final model is trained on 2022-2024. Dates in 2025 are a fair test; earlier dates were used for training.

## Pictures
### ML pipeline
![ML pipeline](figures/01_machine_learning_pipeline_of_this_project.png)

### Carbon intensity over time and the data split (drift)
![Carbon intensity over time and the data split (drift)](figures/02_carbon_intensity_over_time_and_the_data_split.png)

### Test results on 2025
![Test results on 2025](figures/10_test_results_on_2025_lower_is_better.png)

### RQ2: error for each of the 48 half-hours
![RQ2: error for each of the 48 half-hours](figures/13_rq2_mae_for_each_of_the_48_half_hours_2025.png)

### RQ3: historical vs forecast weather
![RQ3: historical vs forecast weather](figures/14_rq3_historical_vs_forecast_weather_2025.png)

### RQ4: window regret and hit rate
![RQ4: window regret and hit rate](figures/15_regret_lower_is_better.png)

### Predicted vs actual
![Predicted vs actual](figures/20_predicted_vs_actual_every_half_hour_of_2025.png)

### Permutation importance
![Permutation importance](figures/22_permutation_importance_of_feature_groups.png)

### Live forecast
![Live forecast](figures/27_live_forecast_for_2026_11_21.png)
